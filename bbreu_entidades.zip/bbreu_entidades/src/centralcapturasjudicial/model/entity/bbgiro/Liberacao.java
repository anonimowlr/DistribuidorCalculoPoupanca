/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package centralcapturasjudicial.model.entity.bbgiro;

import centralcapturasjudicial.model.entity.AbstractEntity;
import centralcapturasjudicial.model.entity.bbgiro.*;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author f3295813
 */

@Entity
@Table(name="tab_lib")
public class Liberacao implements Serializable, AbstractEntity {
  
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // auto
    @Column(name="id") // nome coluna 
    private Long id;
    
    @Temporal(TemporalType.DATE)
    @Column(name="dt_lib")
    private Date dtLiberacao;
    
    @Column(name="tx_pcl")
    private String txParcela;
    
    @Column(name="vl_prvt")
    private Double vlPrevisto;
    
    @Column(name="vl_libd")
    private Double vlLiberado;
    
     
    @ManyToOne
    @JoinColumn(name="id_item_fncd")    
    private ItemFinanciado itemFinanciado;
    
    
    
    
    
     public HashMap<Integer,String> getValues(){
        SimpleDateFormat fd = new SimpleDateFormat("dd/MM/yyyy");
        
        HashMap<Integer,String> values = new HashMap<>();
        
        
        if(getDtLiberacao() != null){
            
              values.put(1, fd.format(getDtLiberacao()));
        }
        
        else{
            
            values.put(1, "");
        }
        
        
           if(getTxParcela() != null){
            
                values.put(2, getTxParcela());
        }
        
        else{
            
            values.put(2, "");
        }
        
        
        
     
      
        Double v = getVlLiberado();
        Double f = getVlPrevisto();
        
          if(v != null){
            
                values.put(3,String.format("%.2f", v).replace(".", ","));
        }
        
        else{
            
            values.put(3, "");
        }
        
         if(f != null){
            
                values.put(4,String.format("%.2f", f).replace(".", ","));
        }
        
        else{
            
            values.put(4, "");
        }
        
                     
        return values;
        
    }

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the dtLiberacao
     */
    public Date getDtLiberacao() {
        return dtLiberacao;
    }

    /**
     * @param dtLiberacao the dtLiberacao to set
     */
    public void setDtLiberacao(Date dtLiberacao) {
        this.dtLiberacao = dtLiberacao;
    }

    /**
     * @return the txParcela
     */
    public String getTxParcela() {
        return txParcela;
    }

    /**
     * @param txParcela the txParcela to set
     */
    public void setTxParcela(String txParcela) {
        this.txParcela = txParcela;
    }

    /**
     * @return the vlPrevisto
     */
    public Double getVlPrevisto() {
        return vlPrevisto;
    }

    /**
     * @param vlPrevisto the vlPrevisto to set
     */
    public void setVlPrevisto(Double vlPrevisto) {
        this.vlPrevisto = vlPrevisto;
    }

    /**
     * @return the vlLiberado
     */
    public Double getVlLiberado() {
        return vlLiberado;
    }

    /**
     * @param vlLiberado the vlLiberado to set
     */
    public void setVlLiberado(Double vlLiberado) {
        this.vlLiberado = vlLiberado;
    }

    /**
     * @return the itemFinanciado
     */
    public ItemFinanciado getItemFinanciado() {
        return itemFinanciado;
    }

    /**
     * @param itemFinanciado the itemFinanciado to set
     */
    public void setItemFinanciado(ItemFinanciado itemFinanciado) {
        this.itemFinanciado = itemFinanciado;
    }

    

   
}