/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package centralcapturasjudicial.model.entity.descontotitulos;

import centralcapturasjudicial.model.entity.bbgiro.OperacaoGiro;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author f3295813
 */
@Entity
@Table(name = "tab_dett_tit")
public class DetalhamentoTitulo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "id_dsc_tit")
    private DadosDescontoTitulos dadosDescontoTitulos;

    @Column(name = "tx_cli")
    private String txCliente;

    @Column(name = "nr_rms")
    private int nrRemessa;

    @Column(name = "tx_est")
    private String txSituacao;

    @Column(name = "tx_pgdr")
    private String txPagador;

    @Column(name = "vl_nmnl")
    private Double vlNominal;

    @Column(name = "vl_jur_encg")
    private Double vlJurosEncargos;

    @Column(name = "vl_iof_nml")
    private Double vlIOFNormal;

    @Column(name = "vl_cptl_libd")
    private Double vlCapitalLiberado;

    @Column(name = "tx_bco")
    private String txTaxaBanco;

    @Column(name = "tx_pz")
    private String txPrazo;

    @Column(name = "tx_Cpf")
    private String txCpf;

    @Temporal(TemporalType.DATE)
    @Column(name = "dt_lib")
    private Date dtLiberacao;

    @Temporal(TemporalType.DATE)
    @Column(name = "dt_vnct")
    private Date dtVencimento;

    @Column(name = "tx_tip_lqdc")
    private String txTipoLiquidacao;

    @Temporal(TemporalType.DATE)
    @Column(name = "dt_lqdc")
    private Date dtLiquidacao;

    @Column(name = "vl_cmss_pmc")
    private Double vlComissaoPermanencia;

    @Column(name = "vl_jur_mor")
    private Double vlJurosMoratorios;

    @Column(name = "vl_mult")
    private Double vlMulta;

    @Column(name = "vl_iof_andd")
    private Double vlIOFAnormalidade;

    @Column(name = "vl_pc_cbr")
    private Double vlPagoCobranca;
    
    @Column(name = "tx_CBR")
    private String txCBR;

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the dadosDescontoTitulos
     */
    public DadosDescontoTitulos getDadosDescontoTitulos() {
        return dadosDescontoTitulos;
    }

    /**
     * @param dadosDescontoTitulos the dadosDescontoTitulos to set
     */
    public void setDadosDescontoTitulos(DadosDescontoTitulos dadosDescontoTitulos) {
        this.dadosDescontoTitulos = dadosDescontoTitulos;
    }

    /**
     * @return the txCliente
     */
    public String getTxCliente() {
        return txCliente;
    }

    /**
     * @param txCliente the txCliente to set
     */
    public void setTxCliente(String txCliente) {
        this.txCliente = txCliente;
    }

    /**
     * @return the nrRemessa
     */
    public int getNrRemessa() {
        return nrRemessa;
    }

    /**
     * @param nrRemessa the nrRemessa to set
     */
    public void setNrRemessa(int nrRemessa) {
        this.nrRemessa = nrRemessa;
    }

    /**
     * @return the txSituacao
     */
    public String getTxSituacao() {
        return txSituacao;
    }

    /**
     * @param txSituacao the txSituacao to set
     */
    public void setTxSituacao(String txSituacao) {
        this.txSituacao = txSituacao;
    }

    /**
     * @return the txPagador
     */
    public String getTxPagador() {
        return txPagador;
    }

    /**
     * @param txPagador the txPagador to set
     */
    public void setTxPagador(String txPagador) {
        this.txPagador = txPagador;
    }

    /**
     * @return the vlNominal
     */
    public Double getVlNominal() {
        return vlNominal;
    }

    /**
     * @param vlNominal the vlNominal to set
     */
    public void setVlNominal(Double vlNominal) {
        this.vlNominal = vlNominal;
    }

    /**
     * @return the vlJurosEncargos
     */
    public Double getVlJurosEncargos() {
        return vlJurosEncargos;
    }

    /**
     * @param vlJurosEncargos the vlJurosEncargos to set
     */
    public void setVlJurosEncargos(Double vlJurosEncargos) {
        this.vlJurosEncargos = vlJurosEncargos;
    }

    /**
     * @return the vlIOFNormal
     */
    public Double getVlIOFNormal() {
        return vlIOFNormal;
    }

    /**
     * @param vlIOFNormal the vlIOFNormal to set
     */
    public void setVlIOFNormal(Double vlIOFNormal) {
        this.vlIOFNormal = vlIOFNormal;
    }

    /**
     * @return the vlCapitalLiberado
     */
    public Double getVlCapitalLiberado() {
        return vlCapitalLiberado;
    }

    /**
     * @param vlCapitalLiberado the vlCapitalLiberado to set
     */
    public void setVlCapitalLiberado(Double vlCapitalLiberado) {
        this.vlCapitalLiberado = vlCapitalLiberado;
    }

    /**
     * @return the txTaxaBanco
     */
    public String getTxTaxaBanco() {
        return txTaxaBanco;
    }

    /**
     * @param txTaxaBanco the txTaxaBanco to set
     */
    public void setTxTaxaBanco(String txTaxaBanco) {
        this.txTaxaBanco = txTaxaBanco;
    }

    /**
     * @return the txPrazo
     */
    public String getTxPrazo() {
        return txPrazo;
    }

    /**
     * @param txPrazo the txPrazo to set
     */
    public void setTxPrazo(String txPrazo) {
        this.txPrazo = txPrazo;
    }

    /**
     * @return the txCpf
     */
    public String getTxCpf() {
        return txCpf;
    }

    /**
     * @param txCpf the txCpf to set
     */
    public void setTxCpf(String txCpf) {
        this.txCpf = txCpf;
    }

    /**
     * @return the dtLiberacao
     */
    public Date getDtLiberacao() {
        return dtLiberacao;
    }

    /**
     * @param dtLiberacao the dtLiberacao to set
     */
    public void setDtLiberacao(Date dtLiberacao) {
        this.dtLiberacao = dtLiberacao;
    }

    /**
     * @return the dtVencimento
     */
    public Date getDtVencimento() {
        return dtVencimento;
    }

    /**
     * @param dtVencimento the dtVencimento to set
     */
    public void setDtVencimento(Date dtVencimento) {
        this.dtVencimento = dtVencimento;
    }

    /**
     * @return the txTipoLiquidacao
     */
    public String getTxTipoLiquidacao() {
        return txTipoLiquidacao;
    }

    /**
     * @param txTipoLiquidacao the txTipoLiquidacao to set
     */
    public void setTxTipoLiquidacao(String txTipoLiquidacao) {
        this.txTipoLiquidacao = txTipoLiquidacao;
    }

    /**
     * @return the dtLiquidacao
     */
    public Date getDtLiquidacao() {
        return dtLiquidacao;
    }

    /**
     * @param dtLiquidacao the dtLiquidacao to set
     */
    public void setDtLiquidacao(Date dtLiquidacao) {
        this.dtLiquidacao = dtLiquidacao;
    }

    /**
     * @return the vlComissaoPermanencia
     */
    public Double getVlComissaoPermanencia() {
        return vlComissaoPermanencia;
    }

    /**
     * @param vlComissaoPermanencia the vlComissaoPermanencia to set
     */
    public void setVlComissaoPermanencia(Double vlComissaoPermanencia) {
        this.vlComissaoPermanencia = vlComissaoPermanencia;
    }

    /**
     * @return the vlJurosMoratorios
     */
    public Double getVlJurosMoratorios() {
        return vlJurosMoratorios;
    }

    /**
     * @param vlJurosMoratorios the vlJurosMoratorios to set
     */
    public void setVlJurosMoratorios(Double vlJurosMoratorios) {
        this.vlJurosMoratorios = vlJurosMoratorios;
    }

    /**
     * @return the vlMulta
     */
    public Double getVlMulta() {
        return vlMulta;
    }

    /**
     * @param vlMulta the vlMulta to set
     */
    public void setVlMulta(Double vlMulta) {
        this.vlMulta = vlMulta;
    }

    /**
     * @return the vlIOFAnormalidade
     */
    public Double getVlIOFAnormalidade() {
        return vlIOFAnormalidade;
    }

    /**
     * @param vlIOFAnormalidade the vlIOFAnormalidade to set
     */
    public void setVlIOFAnormalidade(Double vlIOFAnormalidade) {
        this.vlIOFAnormalidade = vlIOFAnormalidade;
    }

    /**
     * @return the vlPagoCobranca
     */
    public Double getVlPagoCobranca() {
        return vlPagoCobranca;
    }

    /**
     * @param vlPagoCobranca the vlPagoCobranca to set
     */
    public void setVlPagoCobranca(Double vlPagoCobranca) {
        this.vlPagoCobranca = vlPagoCobranca;
    }

    /**
     * @return the txCBR
     */
    public String getTxCBR() {
        return txCBR;
    }

    /**
     * @param txCBR the txCBR to set
     */
    public void setTxCBR(String txCBR) {
        this.txCBR = txCBR;
    }
    
       public HashMap<Integer,String> getValues(){
       SimpleDateFormat fd = new SimpleDateFormat("dd/MM/yyyy");
        
           HashMap<Integer, String> values = new HashMap<>();

           values.put(1, getTxCBR());
           values.put(2, String.valueOf(getNrRemessa()));
           values.put(3, getTxPagador());
           values.put(4, getTxCpf());
           values.put(5, String.valueOf(getVlNominal()).replace(".", ","));
           values.put(6, String.valueOf(getVlCapitalLiberado()).replace(".", ","));
           values.put(7, String.valueOf(getVlJurosEncargos()).replace(".", ","));
           values.put(8, String.valueOf(getVlIOFNormal()).replace(".", ","));
           values.put(9, getTxTaxaBanco());
           values.put(10, getTxPrazo());
           values.put(11, fd.format(getDtLiberacao()));
           values.put(12, fd.format(getDtVencimento()));
           values.put(13, getTxTipoLiquidacao());
           values.put(14, fd.format(getDtLiquidacao()));
           values.put(15, getTxSituacao());
           values.put(16, String.valueOf(getVlPagoCobranca()).replace(".", ","));
           values.put(17, String.valueOf(getVlComissaoPermanencia()).replace(".", ","));
           values.put(18, String.valueOf(getVlIOFAnormalidade()).replace(".", ","));
           values.put(19, String.valueOf(getVlJurosMoratorios()).replace(".", ","));
           values.put(20, String.valueOf(getVlMulta()).replace(".", ","));

           
             
            
    return values;
            
            }

}
