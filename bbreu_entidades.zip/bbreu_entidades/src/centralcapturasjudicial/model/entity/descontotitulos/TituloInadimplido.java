/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package centralcapturasjudicial.model.entity.descontotitulos;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author f3295813
 */
@Entity
@Table(name = "tab_tit_indt")
public class TituloInadimplido {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "id_dsc_tit")
    private DadosDescontoTitulos dadosDescontoTitulos;

    @Temporal(TemporalType.DATE)
    @Column(name = "dt_lib")
    private Date dtLiberacao;

    @Column(name = "tx_pz")
    private String txPrazo;

    @Column(name = "vl_ttl")
    private Double vlTotal;

    @Column(name = "vl_lqdo")
    private Double vlLiquido;

    @Column(name = "vl_jur_encg")
    private Double vlJurosEncargos;

    @Column(name = "vl_iof_nml")
    private Double vlIOFNormal;

    @Column(name = "vl_cmss_pmc")
    private Double vlJurosComissaoPerm;

    @Column(name = "vl_jur_mor")
    private Double vlJurosMoratorios;

    @Column(name = "vl_mult")
    private Double vlMulta;

    @Column(name = "vl_amtz")
    private Double vlAmortizacao;

    @Column(name = "tx_sac")
    private String txSacado;

    @Column(name = "vl_taxa")
    private Double vlTaxa;

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the dadosDescontoTitulos
     */
    public DadosDescontoTitulos getDadosDescontoTitulos() {
        return dadosDescontoTitulos;
    }

    /**
     * @param dadosDescontoTitulos the dadosDescontoTitulos to set
     */
    public void setDadosDescontoTitulos(DadosDescontoTitulos dadosDescontoTitulos) {
        this.dadosDescontoTitulos = dadosDescontoTitulos;
    }

    /**
     * @return the dtLiberacao
     */
    public Date getDtLiberacao() {
        return dtLiberacao;
    }

    /**
     * @param dtLiberacao the dtLiberacao to set
     */
    public void setDtLiberacao(Date dtLiberacao) {
        this.dtLiberacao = dtLiberacao;
    }

    /**
     * @return the txPrazo
     */
    public String getTxPrazo() {
        return txPrazo;
    }

    /**
     * @param txPrazo the txPrazo to set
     */
    public void setTxPrazo(String txPrazo) {
        this.txPrazo = txPrazo;
    }

    /**
     * @return the vlTotal
     */
    public Double getVlTotal() {
        return vlTotal;
    }

    /**
     * @param vlTotal the vlTotal to set
     */
    public void setVlTotal(Double vlTotal) {
        this.vlTotal = vlTotal;
    }

    /**
     * @return the vlLiquido
     */
    public Double getVlLiquido() {
        return vlLiquido;
    }

    /**
     * @param vlLiquido the vlLiquido to set
     */
    public void setVlLiquido(Double vlLiquido) {
        this.vlLiquido = vlLiquido;
    }

    /**
     * @return the vlJurosEncargos
     */
    public Double getVlJurosEncargos() {
        return vlJurosEncargos;
    }

    /**
     * @param vlJurosEncargos the vlJurosEncargos to set
     */
    public void setVlJurosEncargos(Double vlJurosEncargos) {
        this.vlJurosEncargos = vlJurosEncargos;
    }

    /**
     * @return the vlIOFNormal
     */
    public Double getVlIOFNormal() {
        return vlIOFNormal;
    }

    /**
     * @param vlIOFNormal the vlIOFNormal to set
     */
    public void setVlIOFNormal(Double vlIOFNormal) {
        this.vlIOFNormal = vlIOFNormal;
    }

    /**
     * @return the vlJurosComissaoPerm
     */
    public Double getVlJurosComissaoPerm() {
        return vlJurosComissaoPerm;
    }

    /**
     * @param vlJurosComissaoPerm the vlJurosComissaoPerm to set
     */
    public void setVlJurosComissaoPerm(Double vlJurosComissaoPerm) {
        this.vlJurosComissaoPerm = vlJurosComissaoPerm;
    }

    /**
     * @return the vlJurosMoratorios
     */
    public Double getVlJurosMoratorios() {
        return vlJurosMoratorios;
    }

    /**
     * @param vlJurosMoratorios the vlJurosMoratorios to set
     */
    public void setVlJurosMoratorios(Double vlJurosMoratorios) {
        this.vlJurosMoratorios = vlJurosMoratorios;
    }

    /**
     * @return the vlMulta
     */
    public Double getVlMulta() {
        return vlMulta;
    }

    /**
     * @param vlMulta the vlMulta to set
     */
    public void setVlMulta(Double vlMulta) {
        this.vlMulta = vlMulta;
    }

    /**
     * @return the vlAmortizacao
     */
    public Double getVlAmortizacao() {
        return vlAmortizacao;
    }

    /**
     * @param vlAmortizacao the vlAmortizacao to set
     */
    public void setVlAmortizacao(Double vlAmortizacao) {
        this.vlAmortizacao = vlAmortizacao;
    }

    /**
     * @return the txSacado
     */
    public String getTxSacado() {
        return txSacado;
    }

    /**
     * @param txSacado the txSacado to set
     */
    public void setTxSacado(String txSacado) {
        this.txSacado = txSacado;
    }

    /**
     * @return the vlTaxa
     */
    public Double getVlTaxa() {
        return vlTaxa;
    }

    /**
     * @param vlTaxa the vlTaxa to set
     */
    public void setVlTaxa(Double vlTaxa) {
        this.vlTaxa = vlTaxa;
    }

 
    
}
