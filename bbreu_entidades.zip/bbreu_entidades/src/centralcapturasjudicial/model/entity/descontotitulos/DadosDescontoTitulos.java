/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package centralcapturasjudicial.model.entity.descontotitulos;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author f3295813
 */
 @Entity
@Table(name="tab_dsc_tit")
public class DadosDescontoTitulos {
   
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // auto
    @Column(name="id") // nome coluna 
    private Long id;
          
    @Column(name="nr_age")
    private int nrAgencia;
    
    @Column(name="nr_opr")
    private int nrOperacao;
    
      
    @Temporal(TemporalType.DATE)
    @Column(name="dt_inc")
    private Date dtInicio;
    
         
    @Temporal(TemporalType.DATE)
    @Column(name="dt_fim")
    private Date dtFim;
    
      @Column(name="tx_lnh_crd")
    private String txLinhaCredito;
    
    
    @OneToMany(mappedBy = "dadosDescontoTitulos", cascade = CascadeType.ALL, fetch = FetchType.LAZY)    // nome da classe mappedBy
    private List<DetalhamentoTitulo> listDetalhamentoTitulo;
    
    
     @OneToMany(mappedBy = "dadosDescontoTitulos", cascade = CascadeType.ALL, fetch = FetchType.LAZY)    // nome da classe mappedBy
    private List<TituloLiquidado> listTituloLiquidado;
    
    
    
      @OneToMany(mappedBy = "dadosDescontoTitulos", cascade = CascadeType.ALL, fetch = FetchType.LAZY)    // nome da classe mappedBy
  private  List<TituloInadimplido> listTituloInadimplido;
      
      
         public HashMap<Integer,String> getValues(){
       SimpleDateFormat fd = new SimpleDateFormat("dd/MM/yyyy");
        
        HashMap<Integer,String> values = new HashMap<>();
        
             values.put(1, String.valueOf(getNrAgencia()));
             values.put(2, String.valueOf(getNrOperacao()));
             values.put(3, fd.format(getDtFim()));
             values.put(4, fd.format(getDtInicio()));
           
           
//        values.put(4, String.valueOf(getVlSaldoArrendamento()).replace(".",","));
//        values.put(1, Integer.toString(getMesCartao().getExtrato().getCartao().getOperacao()));
//        values.put(2, getMesCartao().getDataVencimento().replace(".", "/"));
//        if(Double.toString(getMesCartao().getTxJuros()) != null) {
//            values.put(3, String.format("%.2f", (getMesCartao().getTxJuros())).replace(".", ","));
//        }
//        else {
//            values.put(3, ""); 
//        }
//        values.put(4, getDataTransacao().replace(".", "/"));
//        values.put(5, Integer.toString(getNrCartao()));
//        values.put(6, getDescricao());
//        values.put(7, String.format("%.2f", (getValor())).replace(".", ","));        
//        values.put(8, getMoeda());
        //values.put(9, String.format("%.2f", 1.5));
        //values.put(6, getMes().getDataFaturamento());
                        
        return values;
    }

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the nrAgencia
     */
    public int getNrAgencia() {
        return nrAgencia;
    }

    /**
     * @param nrAgencia the nrAgencia to set
     */
    public void setNrAgencia(int nrAgencia) {
        this.nrAgencia = nrAgencia;
    }

    /**
     * @return the nrOperacao
     */
    public int getNrOperacao() {
        return nrOperacao;
    }

    /**
     * @param nrOperacao the nrOperacao to set
     */
    public void setNrOperacao(int nrOperacao) {
        this.nrOperacao = nrOperacao;
    }

    /**
     * @return the dtInicio
     */
    public Date getDtInicio() {
        return dtInicio;
    }

    /**
     * @param dtInicio the dtInicio to set
     */
    public void setDtInicio(Date dtInicio) {
        this.dtInicio = dtInicio;
    }

    /**
     * @return the dtFim
     */
    public Date getDtFim() {
        return dtFim;
    }

    /**
     * @param dtFim the dtFim to set
     */
    public void setDtFim(Date dtFim) {
        this.dtFim = dtFim;
    }

    /**
     * @return the txLinhaCredito
     */
    public String getTxLinhaCredito() {
        return txLinhaCredito;
    }

    /**
     * @param txLinhaCredito the txLinhaCredito to set
     */
    public void setTxLinhaCredito(String txLinhaCredito) {
        this.txLinhaCredito = txLinhaCredito;
    }

    /**
     * @return the listDetalhamentoTitulo
     */
    public List<DetalhamentoTitulo> getListDetalhamentoTitulo() {
        return listDetalhamentoTitulo;
    }

    /**
     * @param listDetalhamentoTitulo the listDetalhamentoTitulo to set
     */
    public void setListDetalhamentoTitulo(List<DetalhamentoTitulo> listDetalhamentoTitulo) {
        this.listDetalhamentoTitulo = listDetalhamentoTitulo;
    }

    /**
     * @return the listTituloLiquidado
     */
    public List<TituloLiquidado> getListTituloLiquidado() {
        return listTituloLiquidado;
    }

    /**
     * @param listTituloLiquidado the listTituloLiquidado to set
     */
    public void setListTituloLiquidado(List<TituloLiquidado> listTituloLiquidado) {
        this.listTituloLiquidado = listTituloLiquidado;
    }

    /**
     * @return the listTituloInadimplido
     */
    public List<TituloInadimplido> getListTituloInadimplido() {
        return listTituloInadimplido;
    }

    /**
     * @param listTituloInadimplido the listTituloInadimplido to set
     */
    public void setListTituloInadimplido(List<TituloInadimplido> listTituloInadimplido) {
        this.listTituloInadimplido = listTituloInadimplido;
    }
    
    
    

}
