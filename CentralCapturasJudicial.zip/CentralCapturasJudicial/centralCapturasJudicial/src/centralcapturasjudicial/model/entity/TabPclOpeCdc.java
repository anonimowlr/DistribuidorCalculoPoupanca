/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package centralcapturasjudicial.model.entity;

import centralcapturasjudicial.model.entity.TabOpeCdc;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author f6323539
 */
@Entity
@Table(name="tab_pcl_ope_cdc"
    ,catalog="calculobbreu"
)

public class TabPclOpeCdc implements java.io.Serializable {
     @Id
     @GeneratedValue(strategy = GenerationType.IDENTITY)
     @Column(name="id", unique=true, nullable=false)
     private Long id;
     @ManyToOne
     @JoinColumn(name="id_ope")   
     private TabOpeCdc tabOpeCdc;
     @OneToMany(mappedBy = "tabPclOpeCdc", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
     private List<TabPgtoPclCdc> tabPgtoPclCdcs = new ArrayList();
     @Column(name="nr_pcl")
     private int nrPcl;
     @Temporal(TemporalType.DATE) 
     @Column(name="dt_vcto", length=10)
     private Date dtVcto;        
     @Temporal(TemporalType.DATE) 
     @Column(name="dt_cobr", length=10) 
     private Date dtCobr;        
     @Temporal(TemporalType.DATE) 
     @Column(name="dt_pgto", length=10)
     private Date dtPgto;
     @Column(name="vl_cap")
     private Double vlCap;
     @Column(name="vl_jur")
     private Double vlJur;

    public TabPclOpeCdc() {
    }    

    public TabPclOpeCdc(TabOpeCdc tabOpeCdc, int nrPcl, Date dtVcto, Date dtCobr, Date dtPgto, Double vlCap, Double vlJur) {
        this.tabOpeCdc = tabOpeCdc;
        this.nrPcl = nrPcl;
        this.dtVcto = dtVcto;
        this.dtCobr = dtCobr;
        this.dtPgto = dtPgto;
        this.vlCap = vlCap;
        this.vlJur = vlJur;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public TabOpeCdc getTabOpeCdc() {
        return tabOpeCdc;
    }

    public void setTabOpeCdc(TabOpeCdc tabOpeCdc) {
        this.tabOpeCdc = tabOpeCdc;
    }

    public List<TabPgtoPclCdc> getTabPgtoPclCdcs() {
        return tabPgtoPclCdcs;
    }

    public void setTabPgtoPclCdcs(List<TabPgtoPclCdc> tabPgtoPclCdcs) {
        this.tabPgtoPclCdcs = tabPgtoPclCdcs;
    }

    public int getNrPcl() {
        return nrPcl;
    }

    public void setNrPcl(int nrPcl) {
        this.nrPcl = nrPcl;
    }

    public Date getDtVcto() {
        return dtVcto;
    }

    public void setDtVcto(Date dtVcto) {
        this.dtVcto = dtVcto;
    }

    public Date getDtCobr() {
        return dtCobr;
    }

    public void setDtCobr(Date dtCobr) {
        this.dtCobr = dtCobr;
    }

    public Date getDtPgto() {
        return dtPgto;
    }

    public void setDtPgto(Date dtPgto) {
        this.dtPgto = dtPgto;
    }

    public Double getVlCap() {
        return vlCap;
    }

    public void setVlCap(Double vlCap) {
        this.vlCap = vlCap;
    }

    public Double getVlJur() {
        return vlJur;
    }

    public void setVlJur(Double vlJur) {
        this.vlJur = vlJur;
    }

    
    public HashMap<Integer,String> getValues(){
        
        DateFormat df = new SimpleDateFormat("dd/MM/yyyy");     
        
        HashMap<Integer,String> values = new HashMap<>();  
        values.put(1, Integer.toString(getNrPcl()));
        
        if(getDtVcto() != null) {
            values.put(2, df.format(getDtVcto())); 
        }
        else {
            values.put(2, ""); 
        }
        
        //values.put(2, df.format(getDtVcto()));
        
        if(getDtCobr() != null) {
            values.put(3, df.format(getDtCobr())); 
        }
        else {
            values.put(3, ""); 
        }
        
        //values.put(3, df.format(getDtCobr())); 
        
        if(getVlJur() != null) {
            values.put(4, String.format("%.2f",(getVlJur())).replace(".", ","));
        }
        else {
            values.put(4, ""); 
        }
        
        //values.put(4, String.format("%.2f",(getVlJur())).replace(".", ","));
        values.put(5, String.format("%.2f",(getVlCap())).replace(".", ","));
        if(getDtPgto() == null) {
           values.put(6, ""); 
        }
        else {
           values.put(6, df.format(getDtPgto())); 
        }   
        return values;
    }

   
    
}
