/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package centralcapturasjudicial.model.entity;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author F6323539
 */

@Entity
@Table(name="tab_pgto_pcl_cdc"
    ,catalog="calculobbreu"
)

public class TabPgtoPclCdc implements java.io.Serializable{
     @Id
     @GeneratedValue(strategy = GenerationType.IDENTITY)
     @Column(name="id", unique=true, nullable=false)
     private Long id;
     @ManyToOne
     @JoinColumn(name="id_pcl")    
     private TabPclOpeCdc tabPclOpeCdc;
     @OneToMany(mappedBy = "tabPgtoPclCdc", cascade = CascadeType.ALL,  fetch = FetchType.LAZY)
     private List<TabCpntPgtoPclCdc> tabCpntPgtoCdcs = new ArrayList();
     @Column(name="nr_rec")
     private short nrRec;
     @Temporal(TemporalType.DATE)
     @Column(name="dt_rec", length=10)
     private Date DtRec;

    public TabPgtoPclCdc() {
    }

    public TabPgtoPclCdc(TabPclOpeCdc tabPclOpeCdc, short nrRec, Date DtRec) {
        this.tabPclOpeCdc = tabPclOpeCdc;
        this.nrRec = nrRec;
        this.DtRec = DtRec;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public TabPclOpeCdc getTabPclOpeCdc() {
        return tabPclOpeCdc;
    }

    public void setTabPclOpeCdc(TabPclOpeCdc tabPclOpeCdc) {
        this.tabPclOpeCdc = tabPclOpeCdc;
    }

    public List<TabCpntPgtoPclCdc> getTabCpntPgtoCdcs() {
        return tabCpntPgtoCdcs;
    }

    public void setTabCpntPgtoCdcs(List<TabCpntPgtoPclCdc> tabCpntPgtoCdcs) {
        this.tabCpntPgtoCdcs = tabCpntPgtoCdcs;
    }

    public short getNrRec() {
        return nrRec;
    }

    public void setNrRec(short nrRec) {
        this.nrRec = nrRec;
    }

    public Date getDtRec() {
        return DtRec;
    }

    public void setDtRec(Date DtRec) {
        this.DtRec = DtRec;
    }
    
    
 
}