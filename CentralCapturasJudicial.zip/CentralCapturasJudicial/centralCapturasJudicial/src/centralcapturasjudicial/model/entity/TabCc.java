/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package centralcapturasjudicial.model.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

/**
 *
 * @author f6323539
 */
@Entity
@Table(name="tab_cc"
    ,catalog="calculobbreu"
)

public class TabCc  implements java.io.Serializable {
//    
    @EmbeddedId    
    private TabCcId id;
    @Column(name="cpf_cli")
    private String cpfCli;
    @Column(name="nome_cli")
    private String nomeCli;
    @Temporal(TemporalType.DATE)
    @Column(name="dt_abtr", length=10)
    private Date dtAbtr;
    
    public TabCcId getId() {
        return this.id;
    }
    public void setId(TabCcId id) {
        this.id = id;
    }                 
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "tabCc")
    private List<TabMesCc> tabMesCcs = new ArrayList();
     
     
    public TabCc() {
    }
    
    public TabCc(TabCcId id) {
        this.id = id;
    }

    public TabCc(String cpfCli, String nomeCli, Date dtAbtr) {
        this.cpfCli = cpfCli;
        this.nomeCli = nomeCli;
        this.dtAbtr = dtAbtr;
    }

    public String getCpfCli() {
        return cpfCli;
    }

    public void setCpfCli(String cpfCli) {
        this.cpfCli = cpfCli;
    }

    public String getNomeCli() {
        return nomeCli;
    }

    public void setNomeCli(String nomeCli) {
        this.nomeCli = nomeCli;
    }

    public Date getDtAbtr() {
        return dtAbtr;
    }

    public void setDtAbtr(Date dtAbtr) {
        this.dtAbtr = dtAbtr;
    }

    public List<TabMesCc> getTabMesCcs() {
        return tabMesCcs;
    }

    public void setTabMesCcs(List<TabMesCc> tabMesCcs) {
        this.tabMesCcs = tabMesCcs;
    }

    
    
    public String[] getCabecalho(int opcao){
        
        if(opcao == 1) {
            String[] cabecalho = {"Data","Nr Histórico","Txt Histórico"," Documento "," Valor ","D/C","Banco","Origem","Lote","Saldo"};
            return cabecalho;
        }
        else {
            String[] cabecalho = {"Data","Nr Histórico","Txt Histórico"," Documento "," Valor ","Saldo"};
            return cabecalho;
        }
    }
    
}



