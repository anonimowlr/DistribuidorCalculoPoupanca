/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package centralcapturasjudicial.model.entity;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.swing.text.MaskFormatter;

/**
 *
 * @author f6323539
 */
@Entity
@Table(name="tab_ope_cdc"
    ,catalog="calculobbreu")

public class TabOpeCdc implements java.io.Serializable, AbstractEntity  {
     @Id
     //@Column(name="id")
     //@Id
     //@GeneratedValue(strategy = GenerationType.IDENTITY)
     @Column(name="id", unique=true, nullable=false)
     private Long id;  
     @Column(name="cpf_cli")
     private String cpfCli;
     @Column(name="nm_cli")
     private String nomeCli;
     @OneToMany(mappedBy = "tabOpeCdc", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
     private List<TabPclOpeCdc> tabPclOpeCdcs = new ArrayList();   
     @OneToMany(mappedBy = "tabOpeCdc", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
     private List<TabCtrVincCdc> tabCtrVincCdcs = new ArrayList();     
     @Column(name="nr_age_deb", length=7)
     private String nrAgeDeb;
     @Column(name="nr_cta_deb", length=20)
     private String nrCtaDeb;   
     @Column(name="vl_tot_fin")
     private Double vlTotFin;
     @Column(name="vl_sol")
     private Double vlSol;
     @Column(name="vl_iof")
     private Double vlIof;
     @Column(name="vl_jur_care")
     private Double vlJurCare;
     @Column(name="vl_base_calc")
     private Double vlBaseCalc;
     @Column(name="vl_prest")
     private Double vlPrest;
     @Column(name="qt_parc")
     private short qtParc;
     @Column(name="nr_dia_parc")
     private byte nrDiaPcl;
     @Temporal(TemporalType.DATE)
     @Column(name="dt_prim_pcl", length=10)
     private Date dtPrimPcl;     
     @Temporal(TemporalType.DATE)
     @Column(name="dt_ult_pcl", length=10)
     private Date dtUltPcl;
     @Column(name="tx_jur_msl")
     private float txJurMsl;
     @Column(name="tx_jur_anual")
     private float txJurAnual;
     @Temporal(TemporalType.DATE) 
     @Column(name="dt_ult_ic", length=10)
     private Date dtUltIc;
     @Temporal(TemporalType.DATE) 
     @Column(name="dt_base_care", length=10)
     private Date dtBaseCare;
     @Temporal(TemporalType.DATE) 
     @Column(name="dt_sdo_dev", length=10)
     private Date dtSdoDev;
     @Column(name="vl_sdo_dev")
     private Double vlSdoDev;
     @Column(name="vl_tot_jur")
     private Double vlTotJur;
     @Temporal(TemporalType.DATE) 
     @Column(name="dt_pcl_ser", length=10)
     private Date dtPclSer;  
     @Column(name="vl_prest_amtz")
     private Double vlPrestAmtz;
     @Column(name="tx_sit")
     private String txSitCdc;
     @Column(name="chave_func")
     private String chaveFunci;
     //@Temporal(TemporalType.TIMESTAMP)
     //@Column(name = "hor_inc_func", columnDefinition="TIMESTAMP")
     @Column(name="hor_inc_func")
     private LocalDateTime hor_inc_func;

    public TabOpeCdc() {
    }

    public TabOpeCdc(String cpfCli, String nomeCli, String nrAgeDeb, String nrCtaDeb, Double vlTotFin, Double vlSol, Double vlIof, Double vlJurCare, Double vlBaseCalc, Double vlPrest, short qtParc, byte nrDiaPcl, Date dtPrimPcl, Date dtUltPcl, float txJurMsl, float txJurAnual, Date dtUltIc, Date dtBaseCare, Date dtSdoDev, Double vlSdoDev, Double vlTotJur, Date dtPclSer, Double vlPrestAmtz, String txSitCdc, String chaveFunci, LocalDateTime hor_inc_func) {
        this.cpfCli = cpfCli;
        this.nomeCli = nomeCli;
        this.nrAgeDeb = nrAgeDeb;
        this.nrCtaDeb = nrCtaDeb;
        this.vlTotFin = vlTotFin;
        this.vlSol = vlSol;
        this.vlIof = vlIof;
        this.vlJurCare = vlJurCare;
        this.vlBaseCalc = vlBaseCalc;
        this.vlPrest = vlPrest;
        this.qtParc = qtParc;
        this.nrDiaPcl = nrDiaPcl;
        this.dtPrimPcl = dtPrimPcl;
        this.dtUltPcl = dtUltPcl;
        this.txJurMsl = txJurMsl;
        this.txJurAnual = txJurAnual;
        this.dtUltIc = dtUltIc;
        this.dtBaseCare = dtBaseCare;
        this.dtSdoDev = dtSdoDev;
        this.vlSdoDev = vlSdoDev;
        this.vlTotJur = vlTotJur;
        this.dtPclSer = dtPclSer;
        this.vlPrestAmtz = vlPrestAmtz;
        this.txSitCdc = txSitCdc;
        this.chaveFunci = chaveFunci;
        this.hor_inc_func = hor_inc_func;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCpfCli() {
        return cpfCli;
    }

    public void setCpfCli(String cpfCli) {
        this.cpfCli = cpfCli;
    }

    public String getNomeCli() {
        return nomeCli;
    }

    public void setNomeCli(String nomeCli) {
        this.nomeCli = nomeCli;
    }

    public List<TabPclOpeCdc> getTabPclOpeCdcs() {
        return tabPclOpeCdcs;
    }

    public void setTabPclOpeCdcs(List<TabPclOpeCdc> tabPclOpeCdcs) {
        this.tabPclOpeCdcs = tabPclOpeCdcs;
    }

    public List<TabCtrVincCdc> getTabCtrVincCdcs() {
        return tabCtrVincCdcs;
    }

    public void setTabCtrVincCdcs(List<TabCtrVincCdc> tabCtrVincCdcs) {
        this.tabCtrVincCdcs = tabCtrVincCdcs;
    }

    public String getNrAgeDeb() {
        return nrAgeDeb;
    }

    public void setNrAgeDeb(String nrAgeDeb) {
        this.nrAgeDeb = nrAgeDeb;
    }

    public String getNrCtaDeb() {
        return nrCtaDeb;
    }

    public void setNrCtaDeb(String nrCtaDeb) {
        this.nrCtaDeb = nrCtaDeb;
    }

    public Double getVlTotFin() {
        return vlTotFin;
    }

    public void setVlTotFin(Double vlTotFin) {
        this.vlTotFin = vlTotFin;
    }

    public Double getVlSol() {
        return vlSol;
    }

    public void setVlSol(Double vlSol) {
        this.vlSol = vlSol;
    }

    public Double getVlIof() {
        return vlIof;
    }

    public void setVlIof(Double vlIof) {
        this.vlIof = vlIof;
    }

    public Double getVlJurCare() {
        return vlJurCare;
    }

    public void setVlJurCare(Double vlJurCare) {
        this.vlJurCare = vlJurCare;
    }

    public Double getVlBaseCalc() {
        return vlBaseCalc;
    }

    public void setVlBaseCalc(Double vlBaseCalc) {
        this.vlBaseCalc = vlBaseCalc;
    }

    public Double getVlPrest() {
        return vlPrest;
    }

    public void setVlPrest(Double vlPrest) {
        this.vlPrest = vlPrest;
    }

    public short getQtParc() {
        return qtParc;
    }

    public void setQtParc(short qtParc) {
        this.qtParc = qtParc;
    }

    public byte getNrDiaPcl() {
        return nrDiaPcl;
    }

    public void setNrDiaPcl(byte nrDiaPcl) {
        this.nrDiaPcl = nrDiaPcl;
    }

    public Date getDtPrimPcl() {
        return dtPrimPcl;
    }

    public void setDtPrimPcl(Date dtPrimPcl) {
        this.dtPrimPcl = dtPrimPcl;
    }

    public String getChaveFunci() {
        return chaveFunci;
    }

    public void setChaveFunci(String chaveFunci) {
        this.chaveFunci = chaveFunci;
    }

    public LocalDateTime getHor_inc_func() {
        return hor_inc_func;
    }

    public void setHor_inc_func(LocalDateTime hor_inc_func) {
        this.hor_inc_func = hor_inc_func;
    }

    public Date getDtUltPcl() {
        return dtUltPcl;
    }

    public void setDtUltPcl(Date dtUltPcl) {
        this.dtUltPcl = dtUltPcl;
    }

    public float getTxJurMsl() {
        return txJurMsl;
    }

    public void setTxJurMsl(float txJurMsl) {
        this.txJurMsl = txJurMsl;
    }

    public float getTxJurAnual() {
        return txJurAnual;
    }

    public void setTxJurAnual(float txJurAnual) {
        this.txJurAnual = txJurAnual;
    }

    public Date getDtUltIc() {
        return dtUltIc;
    }

    public void setDtUltIc(Date dtUltIc) {
        this.dtUltIc = dtUltIc;
    }

    public Date getDtBaseCare() {
        return dtBaseCare;
    }

    public void setDtBaseCare(Date dtBaseCare) {
        this.dtBaseCare = dtBaseCare;
    }

    public Date getDtSdoDev() {
        return dtSdoDev;
    }

    public void setDtSdoDev(Date dtSdoDev) {
        this.dtSdoDev = dtSdoDev;
    }

    public Double getVlSdoDev() {
        return vlSdoDev;
    }

    public void setVlSdoDev(Double vlSdoDev) {
        this.vlSdoDev = vlSdoDev;
    }

    public Double getVlTotJur() {
        return vlTotJur;
    }

    public void setVlTotJur(Double vlTotJur) {
        this.vlTotJur = vlTotJur;
    }

    public Date getDtPclSer() {
        return dtPclSer;
    }

    public void setDtPclSer(Date dtPclSer) {
        this.dtPclSer = dtPclSer;
    }

    public Double getVlPrestAmtz() {
        return vlPrestAmtz;
    }

    public void setVlPrestAmtz(Double vlPrestAmtz) {
        this.vlPrestAmtz = vlPrestAmtz;
    }

    public String getTxSitCdc() {
        return txSitCdc;
    }

    public void setTxSitCdc(String txSitCdc) {
        this.txSitCdc = txSitCdc;
    }
    
    public String[] getCabecalhoOperacao(){
                        
        String[] cabecalho = {"Operação","    CPF     ","Situação da Operação","Agência","Conta","Total Financiado", "Valor Solicitado","Valor IOF","Juros Carência","Base Cálculo","Valor Prestação","Qt Parc.",
        "Dia","Prim. Parc.","ÚUlt. Parc.","Juros Mensal", "Juros Anual","Últ. Indice", "Base de Carência","Saldo Devedor","Saldo Devedor","Total Juros"};
        
        return cabecalho;
    }
     
    public String[] getCabecalhoParcelas(){
                        
        String[] cabecalho = {"Parcela","Data Vcto","Data Cobrança","   Juros   ","   Capital   ","Data Pgto","Nr Rec.", "Data Receb.","Componentes do Pgto"," Valor "};
        
        return cabecalho;
    } 
     
    public String[] getCabecalhoContratos(){
                        
        String[] cabecalho = {"Contrato","Sistema","Agência","Operação","Saldo Devedor", "Saldo Renegociado"};
        
        return cabecalho;
    } 
    
    public HashMap<Integer,String> getValues() throws ParseException{
        
        DateFormat df = new SimpleDateFormat("dd/MM/yyyy"); 
        MaskFormatter mf = new MaskFormatter("###.###.###-##"); 
        mf.setValueContainsLiteralCharacters(false);
        HashMap<Integer,String> values = new HashMap<>();
        values.put(1, Long.toString(getId()));
        values.put(2, mf.valueToString(String.format("%011d", Long.parseLong(getCpfCli()))));    
        values.put(3, getTxSitCdc());
        values.put(4, getNrAgeDeb());
        values.put(5, getNrCtaDeb());
        values.put(6, String.format("%.2f", (getVlTotFin())).replace(".", ",")); 
        values.put(7, String.format("%.2f", (getVlSol())).replace(".", ",")); 
        values.put(8, String.format("%.2f", (getVlIof())).replace(".", ",")); 
        values.put(9, String.format("%.2f", (getVlJurCare())).replace(".", ","));
        
        if(getVlBaseCalc() != null) {
            values.put(10, String.format("%.2f", (getVlBaseCalc())).replace(".", ","));
        }
        else {
            values.put(10, ""); 
        }
        values.put(11, String.format("%.2f",(getVlPrest())).replace(".", ","));
        values.put(12, Short.toString(getQtParc()));
        values.put(13, Byte.toString(getNrDiaPcl()));
        values.put(14, df.format(getDtPrimPcl()));
        
        if(getDtUltPcl() != null) {
            values.put(15, df.format(getDtUltPcl()));
        }
        else {
            values.put(15, ""); 
        }
        values.put(16, String.format("%.2f",(getTxJurMsl())).replace(".", ","));
        values.put(17, String.format("%.2f",(getTxJurAnual())).replace(".", ","));
        
        if(getDtUltIc() != null) {
            values.put(18, df.format(getDtUltIc()));
        }
        else {
            values.put(18, ""); 
        }
        if(getDtBaseCare() != null) {
            values.put(19, df.format(getDtBaseCare()));
        }
        else {
            values.put(19, ""); 
        }
        values.put(20, df.format(getDtSdoDev()));
        
        if(getVlSdoDev() != null) {
            values.put(21, String.format("%.2f",(getVlSdoDev())).replace(".", ","));
        }
        else {
            values.put(21, ""); 
        }
        if(getVlTotJur() != null) {
            values.put(22, String.format("%.2f",(getVlTotJur())).replace(".", ",")); 
        }
        else {
            values.put(22, ""); 
        }   
        return values;
    }
    
}    



