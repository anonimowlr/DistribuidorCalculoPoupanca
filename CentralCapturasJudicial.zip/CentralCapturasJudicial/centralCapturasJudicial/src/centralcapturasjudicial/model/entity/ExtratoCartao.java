/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package centralcapturasjudicial.model.entity;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author f8940147
 */
@Entity
@Table(name="tab_extrato_cartao")
public class ExtratoCartao implements Serializable, AbstractEntity {
    
    @Id    
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    //@ManyToOne
    @JoinColumn(name="cartao_operacao")//é utilizado para nomearmos a coluna que possui a chave-estrangeira requerida pela associação
    
    @ManyToOne(cascade = CascadeType.ALL)
    /*
    @ManyToOne->Tem-se a classe ExtratoCartao que 
    possui um cartao.
    
    Cada CartaoCredito pode estar em nenhum ou muitos
    ExtratoCartao
    
    Após criado o relacionamento de muitos para um (@ManyToOne)
    , é possível criar o relacionamento de um para muitos 
    na tabela de CartaoCredito, dessa forma podemos ter 
    acesso a lista de ExtratoCartao que se relaciona com o 
    CartaoCredito em questão
    
    @JoinColumn, define qual coluna é responsável pela
    ligação entre os objetos.
    */
    private CartaoCredito cartao;
    @Column(name="cpf_cli")
    private String cpfCli;
    @Column(name="nome_cli")
    private String nomeCli;
    @Column(name="chave_func")
    private String chaveFunci;
    @Column(name="hor_inc_func")
    private LocalDateTime hor_inc_func;
    //@Transient
    @OneToMany(mappedBy = "extrato", cascade = CascadeType.ALL)
    private List<Mes> listMeses;

    public String getChaveFunci() {
        return chaveFunci;
    }

    public void setChaveFunci(String chaveFunci) {
        this.chaveFunci = chaveFunci;
    }

    public LocalDateTime getHor_inc_func() {
        return hor_inc_func;
    }

    public void setHor_inc_func(LocalDateTime hor_inc_func) {
        this.hor_inc_func = hor_inc_func;
    }

    public ExtratoCartao() {
        
    }


    public CartaoCredito getCartao() {
        return cartao;
    }

    public void setCartao(CartaoCredito cartao) {
        this.cartao = cartao;
    }

    public String getCpfCli() {
        return cpfCli;
    }

    public void setCpfCli(String cpfCli) {
        this.cpfCli = cpfCli;
    }

    public String getNomeCli() {
        return nomeCli;
    }

    public void setNomeCli(String nomeCli) {
        this.nomeCli = nomeCli;
    }

    public List<Mes> getListMeses() {
        return listMeses;
    }

    public void setListMeses(List<Mes> listMeses) {
        this.listMeses = listMeses;
    }
    
    @Override
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    
    public String[] getCabecalho(){
                        
        String[] cabecalho = {"Conta","Vencimento","Taxa %","Data Lançamento","Nr Cartão", "Descrição Lançamento","Valor Lançamento","Moeda"};
        
        return cabecalho;
    }
    
    
}
