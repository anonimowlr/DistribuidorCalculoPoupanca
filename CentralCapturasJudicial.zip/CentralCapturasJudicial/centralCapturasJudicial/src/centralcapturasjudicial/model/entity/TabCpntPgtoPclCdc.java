/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package centralcapturasjudicial.model.entity;

/**
 *
 * @author f6323539
 */


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="tab_cpnt_pgto_cdc"
    ,catalog="calculobbreu"
)

public class TabCpntPgtoPclCdc implements java.io.Serializable {
    @Id
     @GeneratedValue(strategy = GenerationType.IDENTITY)
     @Column(name="id", unique=true, nullable=false)
     private Long id;
     @ManyToOne
     @JoinColumn(name="id_pgto")       
     private TabPgtoPclCdc tabPgtoPclCdc;         
     @ManyToOne
     @JoinColumn(name="cd_cpnt")
     private TabTipoCpntCdc tabTipCpntCdc;
     @Column(name="vl_cpnt")
     private Double vlCpnt;

    public TabCpntPgtoPclCdc() {
    }

    public TabCpntPgtoPclCdc(TabPgtoPclCdc tabPgtoPclCdc, TabTipoCpntCdc tabTipCpntCdc, Double vlCpnt) {
        this.tabPgtoPclCdc = tabPgtoPclCdc;
        this.tabTipCpntCdc = tabTipCpntCdc;
        this.vlCpnt = vlCpnt;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public TabPgtoPclCdc getTabPgtoPclCdc() {
        return tabPgtoPclCdc;
    }

    public void setTabPgtoPclCdc(TabPgtoPclCdc tabPgtoPclCdc) {
        this.tabPgtoPclCdc = tabPgtoPclCdc;
    }

    public TabTipoCpntCdc getTabTipCpntCdc() {
        return tabTipCpntCdc;
    }

    public void setTabTipCpntCdc(TabTipoCpntCdc tabTipCpntCdc) {
        this.tabTipCpntCdc = tabTipCpntCdc;
    }

    public Double getVlCpnt() {
        return vlCpnt;
    }

    public void setVlCpnt(Double vlCpnt) {
        this.vlCpnt = vlCpnt;
    }
    
    public HashMap<Integer,String> getValues(){
        
        DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        
        HashMap<Integer,String> values = new HashMap<>();
        values.put(1, Integer.toString(getTabPgtoPclCdc().getTabPclOpeCdc().getNrPcl()));
        values.put(2, df.format(getTabPgtoPclCdc().getTabPclOpeCdc().getDtVcto()));
        
        if(getTabPgtoPclCdc().getTabPclOpeCdc().getDtCobr() != null) {
            values.put(3, df.format(getTabPgtoPclCdc().getTabPclOpeCdc().getDtCobr()));
        }
        else {
            values.put(3, ""); 
        }
        
        //values.put(3, df.format(getTabPgtoPclCdc().getTabPclOpeCdc().getDtCobr()));//ERRO AKI
        
        if(getTabPgtoPclCdc().getTabPclOpeCdc().getVlJur() != null) {
            values.put(4, String.format("%.2f",(getTabPgtoPclCdc().getTabPclOpeCdc().getVlJur())).replace(".", ","));
        }
        else {
            values.put(4, ""); 
        }
        
        //values.put(4, String.format("%.2f",(getTabPgtoPclCdc().getTabPclOpeCdc().getVlJur())).replace(".", ","));
        values.put(5, String.format("%.2f",(getTabPgtoPclCdc().getTabPclOpeCdc().getVlCap())).replace(".", ","));
        if(getTabPgtoPclCdc().getTabPclOpeCdc().getDtPgto() != null) {
           values.put(6, df.format(getTabPgtoPclCdc().getTabPclOpeCdc().getDtPgto())); 
        }   
        else {
           values.put(6, ""); 
        }
        values.put(7, Short.toString(getTabPgtoPclCdc().getNrRec()));
        values.put(8, df.format(getTabPgtoPclCdc().getDtRec()));
        values.put(9, getTabTipCpntCdc().getNome());
        values.put(10, String.format("%.2f", (getVlCpnt())).replace(".", ",")); 
        return values;
    }
}
