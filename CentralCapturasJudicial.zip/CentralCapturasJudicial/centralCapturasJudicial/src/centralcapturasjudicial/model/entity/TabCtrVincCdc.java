/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package centralcapturasjudicial.model.entity;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author f6323539
 */
@Entity
@Table(name="tab_ctr_vinc_cdc"
    ,catalog="calculobbreu"
)

public class TabCtrVincCdc implements java.io.Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id", unique=true, nullable=false)
    private Long id;
    @ManyToOne
    @JoinColumn(name="id_ope")  
    private TabOpeCdc tabOpeCdc;
    @Column(name="nr_ctr")
    private int nrCtr;
    @Column(name="tx_sis")
    private String txSis;
    @Column(name="nr_age")
    private short nrAge;
    @Temporal(TemporalType.DATE) 
    @Column(name="dt_ope", length=10)
    private Date dtOpe;  
    @Column(name="vl_sdo_dev")
    private Double vlSdoDev;
    @Column(name="vl_sdo_ren")
    private Double vlSdorRen;

    public TabCtrVincCdc() {
    }

    public TabCtrVincCdc(TabOpeCdc tabOpeCdc, int nrCtr, String txSis, short nrAge, Date dtOpe, Double vlSdoDev, Double vlSdorRen) {
        this.tabOpeCdc = tabOpeCdc;
        this.nrCtr = nrCtr;
        this.txSis = txSis;
        this.nrAge = nrAge;
        this.dtOpe = dtOpe;
        this.vlSdoDev = vlSdoDev;
        this.vlSdorRen = vlSdorRen;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public TabOpeCdc getTabOpeCdc() {
        return tabOpeCdc;
    }

    public void setTabOpeCdc(TabOpeCdc tabOpeCdc) {
        this.tabOpeCdc = tabOpeCdc;
    }

    public int getNrCtr() {
        return nrCtr;
    }

    public void setNrCtr(int nrCtr) {
        this.nrCtr = nrCtr;
    }

    public String getTxSis() {
        return txSis;
    }

    public void setTxSis(String txSis) {
        this.txSis = txSis;
    }

    public short getNrAge() {
        return nrAge;
    }

    public void setNrAge(short nrAge) {
        this.nrAge = nrAge;
    }

    public Date getDtOpe() {
        return dtOpe;
    }

    public void setDtOpe(Date dtOpe) {
        this.dtOpe = dtOpe;
    }

    public Double getVlSdoDev() {
        return vlSdoDev;
    }

    public void setVlSdoDev(Double vlSdoDev) {
        this.vlSdoDev = vlSdoDev;
    }

    public Double getVlSdorRen() {
        return vlSdorRen;
    }

    public void setVlSdorRen(Double vlSdorRen) {
        this.vlSdorRen = vlSdorRen;
    }
    

    public HashMap<Integer,String> getValues(){
        
        DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        
        HashMap<Integer,String> values = new HashMap<>();
        values.put(1, Integer.toString(getNrCtr()));
        values.put(2, getTxSis());
        values.put(3, Short.toString(getNrAge() ));
        if(getDtOpe() == null) {
           values.put(4, ""); 
        }   
        else {   
           values.put(4, df.format(getDtOpe()));
        }   
        values.put(5, String.format("%.2f", (getVlSdoDev())).replace(".", ",")); 
        values.put(6, String.format("%.2f", (getVlSdorRen())).replace(".", ",")); 
        return values;
    }
}
