/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package centralcapturasjudicial.model.entity;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

/**
 *
 * @author f6323539
 */
@Entity
@Table(name="tab_mes_cc"
    ,catalog="calculobbreu"
)
public class TabMesCc  implements java.io.Serializable {


@Id
    @GeneratedValue(strategy=IDENTITY)
    @Column(name="id", unique=true, nullable=false)
     private long id;
     @ManyToOne()
     @JoinColumns( {
     @JoinColumn(name="nr_age"), @JoinColumn(name="nr_cta")})
     private TabCc tabCc;
     @Column(name="dt_per_lcto", length=7)
     private String dtPerLcto;
     @Temporal(TemporalType.DATE)
     @Column(name="dt_sdo_ant", length=10)
     private Date dtSdoAnt;
     @Column(name="vl_sdo_ant", precision=22, scale=0)
     private Double vlSdoAnt;     
     @Column(name="vl_lim", precision=22, scale=0)
     private Double vlLim;
     @Temporal(TemporalType.DATE)
     @Column(name="dt_vcto", length=10)
     private Date dtVcto;   
     @Column(name="chave_func")
     private String chaveFunci;

    public String getChaveFunci() {
        return chaveFunci;
    }

    public void setChaveFunci(String chaveFunci) {
        this.chaveFunci = chaveFunci;
    }

    public LocalDateTime getHor_inc_func() {
        return hor_inc_func;
    }

    public void setHor_inc_func(LocalDateTime hor_inc_func) {
        this.hor_inc_func = hor_inc_func;
    }
     @Column(name="hor_inc_func")
     private LocalDateTime hor_inc_func;
     @OneToMany(cascade = CascadeType.ALL, mappedBy = "tabMesCc")
     private List<TabLctoCc> tabLctoCcs = new ArrayList();

    public TabMesCc() {
    }
	
    public TabMesCc(TabCc tabCc) {
        this.tabCc = tabCc;
    }
    public TabMesCc(TabCc tabCc, String dtPerLcto, Date dtSdoAnt, Double vlSdoAnt, Double vlLim, Date dtVcto, List tabLctoCcs) {
       this.tabCc = tabCc;
       this.dtPerLcto = dtPerLcto;
       this.dtSdoAnt = dtSdoAnt;
       this.vlSdoAnt = vlSdoAnt;
       this.vlLim = vlLim;
       this.dtVcto = dtVcto;
       this.tabLctoCcs = tabLctoCcs;
    }
   
    public long getId() {
        return this.id;
    }
    
    public void setId(long id) {
        this.id = id;
    }
//
   public TabCc getTabCc() {
        return this.tabCc;
    }
    public void setTabCc(TabCc tabCc) {
        this.tabCc = tabCc;
    }

    
    public String getDtPerLcto() {
        return this.dtPerLcto;
    }
    
    public void setDtPerLcto(String dtPerLcto) {
        this.dtPerLcto = dtPerLcto;
    }

    public Date getDtSdoAnt() {
        return this.dtSdoAnt;
    }
    
    public void setDtSdoAnt(Date dtSdoAnt) {
        this.dtSdoAnt = dtSdoAnt;
    }
    
    public Double getVlSdoAnt() {
        return this.vlSdoAnt;
    }
    
    public void setVlSdoAnt(Double vlSdoAnt) {
        this.vlSdoAnt = vlSdoAnt;
    }
    
    public Double getVlLim() {
        return this.vlLim;
    }
    
    public void setVlLim(Double vlLim) {
        this.vlLim = vlLim;
    }

    public Date getDtVcto() {
        return this.dtVcto;
    }
    
    public void setDtVcto(Date dtVcto) {
        this.dtVcto = dtVcto;
    }

    
    public List<TabLctoCc> getTabLctoCcs() {
        return this.tabLctoCcs;
    }
    
    public void setTabLctoCcs(List tabLctoCcs) {
        this.tabLctoCcs = tabLctoCcs;
    }


}



