/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package centralcapturasjudicial.model.entity;

import java.io.Serializable;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author f8940147
 */
@Entity
@Table(name="tab_mes")
public class Mes implements Serializable {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    @EmbeddedId
    private int id;
    @JoinColumn(name="fatura")
    @ManyToOne//(cascade = CascadeType.ALL)
    private ExtratoCartao extrato;    
    private double txJuros;
    private String dataVencimento;
    private String dataFaturamento;
    private double saldoReal;
    private double saldoDolar;
    private double saldoTotal;
    //@Transient
    @OneToMany(mappedBy = "mes", cascade=CascadeType.ALL)
    private List<Lancamento> listLancamentos;
    

    public Mes() {
    }

    public double getTxJuros() {
        return txJuros;
    }

    public void setTxJuros(double txJuros) {
        this.txJuros = txJuros;
    }

    public String getDataVencimento() {
        return dataVencimento;
    }

    public void setDataVencimento(String dataVencimento) {
        this.dataVencimento = dataVencimento;
    }

    public String getDataFaturamento() {
        return dataFaturamento;
    }

    public void setDataFaturamento(String dataFaturamento) {
        this.dataFaturamento = dataFaturamento;
    }

    public double getSaldoReal() {
        return saldoReal;
    }

    public void setSaldoReal(double saldoReal) {
        this.saldoReal = saldoReal;
    }

    public double getSaldoDolar() {
        return saldoDolar;
    }

    public void setSaldoDolar(double saldoDolar) {
        this.saldoDolar = saldoDolar;
    }

    public double getSaldoTotal() {
        return saldoTotal;
    }

    public void setSaldoTotal(double saldoTotal) {
        this.saldoTotal = saldoTotal;
    }

    public List<Lancamento> getListLancamentos() {
        return listLancamentos;
    }

    public void setListLancamentos(List<Lancamento> listLancamentos) {
        this.listLancamentos = listLancamentos;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public ExtratoCartao getExtrato() {
        return extrato;
    }

    public void setExtrato(ExtratoCartao extrato) {
        this.extrato = extrato;
    }    
    
    
}
