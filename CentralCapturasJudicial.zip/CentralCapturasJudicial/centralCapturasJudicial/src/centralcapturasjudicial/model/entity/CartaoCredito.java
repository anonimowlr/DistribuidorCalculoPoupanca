/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package centralcapturasjudicial.model.entity;

import java.io.Serializable;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import org.hibernate.annotations.Cascade;

/**
 *
 * @author f8940147
 */
@Entity
@Table(name="tab_cartao_credito")
public class CartaoCredito implements Serializable {
    
    @Id
    @Column(name="id_cartao")
    private int operacao;
    @Column(name="produtoModalidade")
    private String produtoModalidade;
   
    
    @OneToMany(mappedBy = "cartao", cascade = CascadeType.ALL)//, fetch = FetchType.LAZY
    //@OneToMany
    //@Transient
    private List<ExtratoCartao> fatura;

    public CartaoCredito() {
    }

    public CartaoCredito(int operacao) {
        this.operacao = operacao;
    }
    
    public int getOperacao() {
        return operacao;
    }

    public void setOperacao(int operacao) {
        this.operacao = operacao;
    }

    public String getProdutoModalidade() {
        return produtoModalidade;
    }

    public void setModalidade(String produtoModalidade) {
        this.produtoModalidade = produtoModalidade;
    }
    
//    public List<ExtratoCartao> getFatura() {
//        return fatura;
//    }
//
//    public void setFatura(List<ExtratoCartao> fatura) {
//        this.fatura = fatura;
//    }
    
    @Override
    public String toString() {
        return Integer.toString(operacao)+ "   " + produtoModalidade;
    }

    
}
