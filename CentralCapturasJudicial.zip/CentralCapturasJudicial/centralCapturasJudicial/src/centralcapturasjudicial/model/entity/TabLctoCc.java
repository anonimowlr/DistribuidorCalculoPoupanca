/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package centralcapturasjudicial.model.entity;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

/**
 *
 * @author f6323539
 */
@Entity
@Table(name="tab_lcto_cc"
    ,catalog="calculobbreu"    
)

public class TabLctoCc  implements java.io.Serializable {
     @Id
     @GeneratedValue(strategy = GenerationType.IDENTITY)
     @Column(name="id", unique=true, nullable=false)
     private long id;   
     @ManyToOne()
     @JoinColumn(name="id_mes") 
     private TabMesCc tabMesCc;
     @Temporal(TemporalType.DATE)
     @Column(name="dt_lcto", length=10)
     private Date dtLcto;
     @Column(name="nr_hst")
     private Integer nrHst;
     @Column(name="tx_hst", length=50)
     private String txHst;
     @Column(name="nr_doc", length=20)
     private String nrDoc;
     @Column(name="vl_doc", precision=22, scale=0)
     private Double vlDoc;
     @Column(name="in_ope_lcto", length=1)
     private Character inOpeLcto;
     @Column(name="vl_sdo", precision=22, scale=0)
     private Double vlSdo;
     @Column(name="nr_bco")
     private Integer nrBco;
     @Column(name="nr_orig")
     private Integer nrOrig;
     @Column(name="nr_lote")
     private Integer nrLote;

    public TabLctoCc() {
    }
	
    public TabLctoCc(long idLcto) {
        this.id = id;
    }
    
    public TabLctoCc(TabMesCc tabMesCc,  Date dtLcto, Integer nrHst, String txHst, String nrDoc, Double vlDoc, Character inOpeLcto, Double vlSdo, Integer nrBco, Integer nrOrig, Integer nrLote) {
       this.tabMesCc = tabMesCc;
       this.dtLcto = dtLcto;
       this.nrHst = nrHst;
       this.txHst = txHst;
       this.nrDoc = nrDoc;
       this.vlDoc = vlDoc;
       this.inOpeLcto = inOpeLcto;
       this.vlSdo = vlSdo;
       this.nrBco = nrBco;
       this.nrOrig = nrOrig;
       this.nrLote = nrLote;
    }
   
    public long getId() {
        return this.id;
    }
    
    public void setId(long id) {
        this.id = id;
    }    

    public Date getDtLcto() {
        return this.dtLcto;
    }
    
    public void setDtLcto(Date dtLcto) {
        this.dtLcto = dtLcto;
    }
    
    
    public Integer getNrHst() {
        return this.nrHst;
    }
    
    public void setNrHst(Integer nrHst) {
        this.nrHst = nrHst;
    }

    
    public String getTxHst() {
        return this.txHst;
    }
    
    public void setTxHst(String txHst) {
        this.txHst = txHst;
    }

    
    public String getNrDoc() {
        return this.nrDoc;
    }
    
    public void setNrDoc(String nrDoc) {
        this.nrDoc = nrDoc;
    }

    
    public Double getVlDoc() {
        return this.vlDoc;
    }
    
    public void setVlDoc(Double vlDoc) {
        this.vlDoc = vlDoc;
    }

    
    public Character getInOpeLcto() {
        return this.inOpeLcto;
    }
    
    public void setInOpeLcto(Character inOpeLcto) {
        this.inOpeLcto = inOpeLcto;
    }
    
    public Double getVlSdo() {
        return this.vlSdo;
    }
    
    public void setVlSdo(Double vlSdo) {
        this.vlSdo = vlSdo;
    }
    
    public Integer getNrBco() {
        return this.nrBco;
    }
    
    public void setNrBco(Integer nrBco) {
        this.nrBco = nrBco;
    }
    
    public Integer getNrOrig() {
        return this.nrOrig;
    }
    
    public void setNrOrig(Integer nrOrig) {
        this.nrOrig = nrOrig;
    }
    
    public Integer getNrLote() {
        return this.nrLote;
    }
    
    public void setNrLote(Integer nrLote) {
        this.nrLote = nrLote;
    }
    
    
    public TabMesCc getTabMesCc() {
        return this.tabMesCc;
    }
    public void setTabMesCc(TabMesCc tabMesCc) {
        this.tabMesCc = tabMesCc;
    }
    
    public HashMap<Integer,String> getValues(int opcao){
        
        DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        HashMap<Integer,String> values = new HashMap<>();
        
        if(opcao == 1) { // Prestação de contas
            values.put(1, df.format(getDtLcto()));
            values.put(2, String.format("%03d", getNrHst()));
            values.put(3, getTxHst());
            values.put(4, getNrDoc()); 
            values.put(5, String.format("%.2f", (getVlDoc())).replace(".", ","));
            values.put(6, Character.toString(getInOpeLcto()));
            if(getNrBco() == null)  {
                values.put(7, "");
            }
            else {
                values.put(7, Integer.toString(getNrBco()));
            } 
            if(getNrOrig() == null)  {
                 values.put(8, "");
            }
            else {
                values.put(8, Integer.toString(getNrOrig()));
            } 
            if(getNrLote() == null)  {
                 values.put(9, "");
            }
            else {
                values.put(9, Integer.toString(getNrLote()));
            } 
            values.put(10, String.format("%.2f", (getVlSdo())).replace(".", ","));
        }    
        else { // Revisional    
            values.put(1, df.format(getDtLcto()));
            if(Character.toString(getInOpeLcto()).equals("D")) {
               values.put(2, "3000"); 
            }
            else {
               values.put(2, "8000"); 
            }
            values.put(3, getTxHst());
            values.put(4, getNrDoc()); 
            values.put(5, String.format("%.2f", (getVlDoc())).replace(".", ","));
            values.put(6, String.format("%.2f", (getVlSdo())).replace(".", ","));
        }
        return values;
    }
}



