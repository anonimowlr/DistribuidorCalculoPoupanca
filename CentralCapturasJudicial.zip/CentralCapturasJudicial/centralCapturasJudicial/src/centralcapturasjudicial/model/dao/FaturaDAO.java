/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package centralcapturasjudicial.model.dao;

import centralcapturasjudicial.model.entity.cartao.ExtratoCartao;
import java.io.Serializable;

/**
 *
 * @author f8940147
 */
public class FaturaDAO extends GenericDAO<ExtratoCartao> implements Serializable {

}
