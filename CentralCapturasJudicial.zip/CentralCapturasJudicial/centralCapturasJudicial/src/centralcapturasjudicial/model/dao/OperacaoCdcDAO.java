/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package centralcapturasjudicial.model.dao;

import centralcapturasjudicial.model.entity.cdc.OperacaoCdc;
import java.io.Serializable;

/**
 *
 * @author f6323539
 */
public class OperacaoCdcDAO extends GenericDAO<OperacaoCdc> implements Serializable {

}
    
